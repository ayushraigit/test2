import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Primary brand blue
  static const Color primary          = Color(0xFF1E4D8C);
  static const Color primaryDark      = Color(0xFF163A6B);
  static const Color primaryLight     = Color(0xFF2E6BC4);
  static const Color primarySurface   = Color(0xFFE8F0FB);

  // Success — green tick, approved hydrants
  static const Color success          = Color(0xFF4CAF50);
  static const Color successSurface   = Color(0xFFE8F5E9);

  // Danger — logout button, warning screen, unapproved hydrants
  static const Color danger           = Color(0xFFC62828);
  static const Color dangerSurface    = Color(0xFFFFEBEE);

  // Hydrant pin colours on map
  static const Color approvedGreen    = Color(0xFF2E7D32);
  static const Color approvedSurface  = Color(0xFFE8F5E9);
  static const Color unapprovedRed    = Color(0xFFC62828);
  static const Color unapprovedSurface = Color(0xFFFFEBEE);
  static const Color selectedBlue     = Color(0xFF1565C0);

  // Backgrounds and surfaces
  static const Color background       = Color(0xFFF5F7FA);
  static const Color surface          = Color(0xFFFFFFFF);
  static const Color border           = Color(0xFFDDE3EF);
  static const Color divider          = Color(0xFFEEF1F7);

  // Text
  static const Color textPrimary      = Color(0xFF0D1B2E);
  static const Color textSecondary    = Color(0xFF4A5568);
  static const Color textMuted        = Color(0xFF9AA5B4);
  static const Color textOnPrimary    = Color(0xFFFFFFFF);
  static const Color textLink         = Color(0xFF1E4D8C);
}
