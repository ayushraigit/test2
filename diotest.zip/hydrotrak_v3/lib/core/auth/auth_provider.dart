import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../api/mock_service.dart';
// import '../api/real_service.dart'; // Uncomment when switching to real API

// ── Auth State ────────────────────────────────────────────────────────────────
class AuthState {
  final bool isAuthenticated;
  final bool isLoading;
  final String? error;
  final String? permitNumber;
  final String? holderName;

  const AuthState({
    this.isAuthenticated = false,
    this.isLoading = false,
    this.error,
    this.permitNumber,
    this.holderName,
  });

  AuthState copyWith({
    bool? isAuthenticated,
    bool? isLoading,
    String? error,
    String? permitNumber,
    String? holderName,
  }) {
    return AuthState(
      isAuthenticated: isAuthenticated ?? this.isAuthenticated,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      permitNumber: permitNumber ?? this.permitNumber,
      holderName: holderName ?? this.holderName,
    );
  }
}

// ── Auth Notifier ─────────────────────────────────────────────────────────────
class AuthNotifier extends StateNotifier<AuthState> {
  static const _storage = FlutterSecureStorage();

  // ── SWAP HERE when real API is ready ──────────────────────────────────────
  final _service = MockService.instance;
  // final _service = RealService.instance;

  AuthNotifier() : super(const AuthState()) {
    _restoreSession();
  }

  // Restore session if user was already logged in
  Future<void> _restoreSession() async {
    final token  = await _storage.read(key: 'access_token');
    final permit = await _storage.read(key: 'permit_number');
    final name   = await _storage.read(key: 'holder_name');

    if (token != null && permit != null) {
      state = state.copyWith(
        isAuthenticated: true,
        permitNumber: permit,
        holderName: name,
      );
    }
  }

  Future<bool> login(String permitNumber, String password) async {
    state = state.copyWith(isLoading: true, error: null);

    try {
      final data = await _service.login(permitNumber.trim(), password);

      // Save tokens securely on device
      await _storage.write(key: 'access_token',  value: data['accessToken']);
      await _storage.write(key: 'permit_number', value: permitNumber.trim());
      await _storage.write(key: 'holder_name',   value: data['holderName'] ?? '');

      state = state.copyWith(
        isAuthenticated: true,
        isLoading: false,
        permitNumber: permitNumber.trim(),
        holderName: data['holderName'],
      );
      return true;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: e.toString().replaceAll('Exception: ', ''),
      );
      return false;
    }
  }

  Future<void> logout() async {
    await _service.logout();
    await _storage.deleteAll();
    state = const AuthState();
  }

  void clearError() {
    state = state.copyWith(error: null);
  }
}

// ── Provider ──────────────────────────────────────────────────────────────────
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>(
  (ref) => AuthNotifier(),
);
