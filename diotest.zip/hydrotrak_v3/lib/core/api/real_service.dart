// ─────────────────────────────────────────────────────────────────────────────
//  REAL SERVICE
//  Fill this in when Iota provides API documentation.
//
//  What you need from Iota before filling this in:
//  ─────────────────────────────────────────────────
//  □ Base API URL for dev / test / prod
//  □ Exact field name for permit number in login request
//  □ Exact field name for token in login response
//  □ Swagger / OpenAPI spec document
//  □ Sandbox permit number + password for testing
//
//  To switch from mock to real:
//  In auth_provider.dart change:
//    final _service = MockService.instance;
//  to:
//    final _service = RealService.instance;
// ─────────────────────────────────────────────────────────────────────────────

import 'package:dio/dio.dart';

class RealService {
  RealService._();
  static final RealService instance = RealService._();

  // TODO: Replace with real URL from Iota
  static const String _baseUrl = 'https://YOUR_API_URL_HERE/v1';

  final Dio _dio = Dio(BaseOptions(
    baseUrl: _baseUrl,
    connectTimeout: const Duration(seconds: 15),
    receiveTimeout: const Duration(seconds: 30),
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
  ));

  // TODO: Confirm exact endpoint path and field names with Iota
  Future<Map<String, dynamic>> login(
    String permitNumber,
    String password,
  ) async {
    final response = await _dio.post('/api/token/auth', data: {
      'permitNumber': permitNumber, // TODO: confirm field name
      'password': password,
    });
    return response.data;
  }

  Future<void> logout() async {
    // TODO: Confirm logout endpoint with Iota
    await _dio.post('/api/token/logout');
  }
}
