// ─────────────────────────────────────────────────────────────────────────────
//  MOCK SERVICE
//  Provides fake data for every API call while real API is not available.
//  When Iota provides real API documentation:
//    1. Fill in real_service.dart with real URLs and field names
//    2. In auth_provider.dart change:
//         final _service = MockService.instance;
//       to:
//         final _service = RealService.instance;
//    Nothing else changes anywhere.
// ─────────────────────────────────────────────────────────────────────────────

class MockService {
  MockService._();
  static final MockService instance = MockService._();

  // Login — accepts any permit number + password "demo"
  Future<Map<String, dynamic>> login(
    String permitNumber,
    String password,
  ) async {
    await Future.delayed(const Duration(milliseconds: 1000));

    if (password.toLowerCase() != 'demo') {
      throw Exception('Invalid permit number or password.');
    }

    return {
      'accessToken': 'mock_access_token_abc123',
      'refreshToken': 'mock_refresh_token_xyz789',
      'permitNumber': permitNumber,
      'holderName': 'John Smith',
    };
  }

  Future<void> logout() async {
    await Future.delayed(const Duration(milliseconds: 500));
  }
}
